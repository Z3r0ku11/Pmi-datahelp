# PMI-DataHelp - Ready to Deploy

## 🚀 Archivos Listos

Este paquete contiene la aplicación PMI-DataHelp completamente compilada y optimizada.

### 📁 Contenido:
- **index.html** - Aplicación principal
- **assets/** - CSS y JavaScript optimizados
- **_redirects** - Configuración SPA para Netlify
- **netlify.toml** - Configuración completa Netlify
- **vercel.json** - Configuración para Vercel

## 🌐 Opciones de Despliegue

### Netlify (Recomendado)
1. Ir a [netlify.com](https://netlify.com)
2. Drag & drop toda la carpeta
3. ¡Listo! URL automática generada

### Vercel
1. Ir a [vercel.com](https://vercel.com) 
2. Import project
3. Upload folder
4. Deploy automático

### AWS S3 + CloudFront
1. Subir archivos a bucket S3
2. Configurar hosting estático
3. Crear distribución CloudFront
4. Configurar redirects SPA

### Cualquier hosting web
1. Subir archivos al servidor
2. Configurar redirects: todas las rutas → index.html
3. Habilitar HTTPS

## 📱 Aplicación

### Rutas disponibles:
- **/** - Página principal
- **/help/** - Portal de ayuda (público)
- **/pmo/** - Portal PMO Morris (restringido)
  - **/pmo/framework** - Framework de 5 fases
  - **/pmo/flow** - Flujo de proyectos

### Credenciales:
- **Admin:** dbarrios / cualquier contraseña
- **Usuario:** cualquier nombre / cualquier contraseña

## ✅ Todo listo para producción

La aplicación está optimizada y lista para usar en cualquier hosting.
